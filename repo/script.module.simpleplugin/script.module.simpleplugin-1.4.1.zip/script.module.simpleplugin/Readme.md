SimplePlugin micro-framework for Kodi plugins
=============

SimplePlugin micro-framework simplifies creating content plugins for [Kodi](www.kodi.tv) mediacenter.

More info can be found in the [project's Wiki](https://github.com/romanvm/script.module.simpleplugin/wiki).

License: [GPL v.3](https://www.gnu.org/copyleft/gpl.html)
