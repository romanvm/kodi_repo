import xbmcgui
#import sys
#sys.path.append('/storage/sdcard0/Python')
#print "******** Testing libtorrent"
#import libtorrent
#print "********* " + dir(libtorrent)

video_vindow = xbmcgui.Window(12005)
label = xbmcgui.ControlLabel(10, 10, 1000, 50,
                            '{0}/{1} | {2} | ET: {3} | Bat: {4}'.format(
                            '$INFO[Player.Time]',
                            '$INFO[Player.Duration]',
                            '$INFO[System.Time]',
                            '$INFO[Player.FinishTime]',
                            '$INFO[System.BatteryLevel]'),
                            textColor="0x7FFFFF00")
video_vindow.addControl(label)
