# -*- coding: utf-8 -*-
# Module: __init__
# Author: Roman V.M.
# Created on: 13.05.2015
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html


