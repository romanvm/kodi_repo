# -*- coding: utf-8 -*-
# Module: main
# Author: Roman V.M.
# Created on: 13.05.2015
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
# todo: implement extended thetvdb API
"""The Main Plugin Module"""

from libs.actions import plugin

plugin.run()
