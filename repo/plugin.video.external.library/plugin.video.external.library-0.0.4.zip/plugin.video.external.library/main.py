# coding: utf-8
# Created on: 20.07.2016
# Author: Roman Miroshnychenko aka Roman V.M. (romanvm@yandex.ua)
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from simpleplugin import debug_exception
from libs.actions import plugin

with debug_exception(plugin.log_error):
    plugin.run()
